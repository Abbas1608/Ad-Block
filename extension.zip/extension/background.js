chrome.runtime.onInstalled.addListener(() => {
    console.log("Pop-up Blocker extension installed");
  });

let adsBlocked = 0;
let totalAds = 0;
// This function simulates blocking ads and counting total ads
function countAds() {
  // Simulate finding ads (you would replace this with actual ad detection logic)
  const foundAds = document.querySelectorAll('.ad').length;
  totalAds += foundAds;

  // Simulate blocking ads (you would replace this with actual blocking logic)
  adsBlocked += foundAds; // Assuming all found ads are blocked

  // Send the counts to the popup
  chrome.storage.local.set({ adsBlocked, totalAds });
}

// Run countAds function when the tab is updated
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    chrome.scripting.executeScript({
      target: { tabId },
      func: countAds,
    });
  }
});

  