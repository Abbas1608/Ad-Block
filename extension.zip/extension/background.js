chrome.runtime.onInstalled.addListener(() => {
    console.log("Pop-up Blocker extension installed");
  });
  